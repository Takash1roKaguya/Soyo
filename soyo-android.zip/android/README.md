# 爽世 App（安卓 WebView 壳）

一个极简的安卓外壳：全屏加载你的聊天地址，鸿蒙用卓易通装上去就是个独立 app。

## 改地址

`app/src/main/java/site/takashirokaguya/soyo/MainActivity.java` 里的 `START_URL`，
现在是 `http://124.71.188.132:8080`。将来上了 HTTPS 域名，改成 `https://soyo.xxx` 就行，
顺手把 `AndroidManifest.xml` 里的 `android:usesCleartextTraffic` 去掉更安全。

## 怎么出安装包（不用装 Android Studio）

1. 在 GitHub 新建一个空仓库，把 `android` 这个文件夹里的东西全部上传（注意 `.github` 也要传）。
2. 仓库 Actions 会自动跑一次 build，绿色勾之后点进去，下载 `soyo-apk` 那个 artifact（里面有 `app-debug.apk`）。
3. 把 apk 传到手机，卓易通里安装。第一次装非商店 app 要允许"安装未知应用"。

本地有 Android 环境的话，直接 `gradle assembleDebug` 也能出。

## 现在这个壳能做到什么程度

- 全屏、无地址栏，返回键先退网页再退出 app
- 记住登录状态（WebView 自带 cookie/dom storage）
- 明文 http 已经放开

## 后面想更像"自己的 app"

- 换图标和启动页（现在借用了系统默认图标）
- 不想再用 AstrBot 的 webchat 页面，就把 `soyo-app/server.py` 那套自建前端部署上去，改 START_URL 指过去
- 想推送收到主动消息：WebView 壳做不了，得换成 Capacitor / React Native 那类，成本高一档
