package site.takashirokaguya.soyo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    // 改成你自己的地址：现在是公网 IP，将来有 HTTPS 域名就换成 https://...
    private static final String START_URL = PollService.BASE;
    private static final int REQ_FILE = 0x5101;
    private static final int REQ_NOTIFY = 0x5102;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "SoyoNative");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                }
                fileCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    if (params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    String[] accept = params != null ? params.getAcceptTypes() : null;
                    // accept 里混着 ".pdf" 这种扩展名，不是合法 MIME，直接用会让选择器打不开
                    List<String> mimes = new ArrayList<>();
                    if (accept != null) {
                        for (String a : accept) {
                            if (a == null) continue;
                            for (String piece : a.split(",")) {
                                String t = piece.trim();
                                if (t.length() > 0 && t.contains("/")) mimes.add(t);
                            }
                        }
                    }
                    if (mimes.isEmpty()) {
                        intent.setType("*/*");
                    } else {
                        intent.setType(mimes.get(0));
                        if (mimes.size() > 1) {
                            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
                        }
                    }
                    startActivityForResult(Intent.createChooser(intent, "选择"), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
        setContentView(web);

        askNotifyPermission();
        startPoll();
    }

    /** 页面把钥匙交过来，后台才能替她盯着。 */
    private class Bridge {
        @JavascriptInterface
        public void setToken(final String t) {
            if (t == null || t.length() == 0) return;
            prefs().edit().putString("token", t).apply();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startPoll();
                }
            });
        }

        @JavascriptInterface
        public void clearToken() {
            prefs().edit().remove("token").remove("lastSeq").apply();
        }

        @JavascriptInterface
        public void ready() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startPoll();
                }
            });
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("soyo", MODE_PRIVATE);
    }

    private void startPoll() {
        String t = prefs().getString("token", "");
        if (t == null || t.length() == 0) return;
        Intent it = new Intent(this, PollService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(it);
            } else {
                startService(it);
            }
        } catch (Exception ignored) {
            // 有的系统不让起服务，页面开着的时候照样能用
        }
    }

    private void askNotifyPermission() {
        if (Build.VERSION.SDK_INT < 33) return;
        try {
            if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIFY);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        PollService.appVisible = true;
    }

    @Override
    protected void onPause() {
        PollService.appVisible = false;
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            Uri[] out = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    out = new Uri[n];
                    for (int i = 0; i < n; i++) {
                        out[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    out = new Uri[]{data.getData()};
                }
            }
            if (fileCallback != null) {
                fileCallback.onReceiveValue(out);
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web != null && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
