package site.takashirokaguya.soyo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * 在后台盯着云端的 /peek，有新消息就弹通知。
 * 用前台服务，免得被系统顺手清掉；那条常驻通知的优先级压到最低。
 */
public class PollService extends Service {

    public static final String BASE = "http://124.71.188.132:8000";

    // 页面开着的时候不弹，免得重复
    public static volatile boolean appVisible = false;

    private static final String CH_ON = "soyo-on";
    private static final String CH_MSG = "soyo-msg";
    private static final int ID_ON = 1;
    private static final long GAP = 45 * 1000L;

    private volatile boolean stopped = false;
    private Thread worker;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(ID_ON, ongoing());
        if (worker == null) {
            worker = new Thread(new Runnable() {
                @Override
                public void run() {
                    loop();
                }
            }, "soyo-poll");
            worker.setDaemon(true);
            worker.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopped = true;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel on = new NotificationChannel(CH_ON, "陪着你",
                NotificationManager.IMPORTANCE_MIN);
        on.setShowBadge(false);
        nm.createNotificationChannel(on);
        NotificationChannel msg = new NotificationChannel(CH_MSG, "她找你",
                NotificationManager.IMPORTANCE_HIGH);
        msg.setDescription("她主动说话的时候提醒你");
        nm.createNotificationChannel(msg);
    }

    private PendingIntent openIntent(int req) {
        Intent it = new Intent(this, MainActivity.class);
        it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(this, req, it, flags);
    }

    private Notification.Builder builder(String channel) {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this, channel);
        }
        return new Notification.Builder(this);
    }

    private Notification ongoing() {
        Notification.Builder b = builder(CH_ON);
        b.setContentTitle("爽世在")
                .setContentText("有话想跟你说的时候会提醒你")
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setOngoing(true)
                .setContentIntent(openIntent(1));
        return b.build();
    }

    private void loop() {
        SharedPreferences sp = getSharedPreferences("soyo", MODE_PRIVATE);
        while (!stopped) {
            try {
                String token = sp.getString("token", "");
                if (token == null || token.length() == 0) {
                    // 登出了就别在后台待着了
                    stopSelf();
                    return;
                }
                check(token, sp);
            } catch (Throwable ignored) {
                // 网络抖一下不算事，下一轮再来
            }
            try {
                Thread.sleep(GAP);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    private void check(String token, SharedPreferences sp) throws Exception {
        String url = BASE + "/peek?token=" + URLEncoder.encode(token, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestMethod("GET");
        int code = c.getResponseCode();
        if (code != 200) {
            c.disconnect();
            return;
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        InputStream in = c.getInputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
        }
        in.close();
        c.disconnect();

        JSONObject obj = new JSONObject(bo.toString("UTF-8"));
        JSONArray arr = obj.optJSONArray("messages");
        if (arr == null) return;

        long last = sp.getLong("lastSeq", 0);
        long top = last;
        List<String> fresh = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject m = arr.optJSONObject(i);
            if (m == null) continue;
            long seq = m.optLong("seq", 0);
            String t = m.optString("text", "");
            if (seq > last && t != null && t.trim().length() > 0) {
                fresh.add(t.trim());
            }
            if (seq > top) top = seq;
        }
        if (top > last) {
            sp.edit().putLong("lastSeq", top).apply();
        }
        if (!fresh.isEmpty() && !appVisible) {
            StringBuilder sb = new StringBuilder();
            for (String t : fresh) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(t);
            }
            notifyMsg(sb.toString());
        }
    }

    private void notifyMsg(String text) {
        String shortText = text.length() > 80 ? text.substring(0, 80) + "…" : text;
        Notification.Builder b = builder(CH_MSG);
        b.setContentTitle("爽世")
                .setContentText(shortText)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setAutoCancel(true)
                .setContentIntent(openIntent((int) (System.currentTimeMillis() & 0xffff)));
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
        }
    }
}
