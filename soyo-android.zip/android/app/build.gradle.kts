plugins {
    id("com.android.application")
}

android {
    namespace = "site.takashirokaguya.soyo"
    compileSdk = 34

    defaultConfig {
        applicationId = "site.takashirokaguya.soyo"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    // 固定一把签名钥匙：不然每次 Action 编出来的签名都不一样，装的时候要先卸载
    signingConfigs {
        create("soyo") {
            storeFile = file("soyo.jks")
            storePassword = "soyo2026key"
            keyAlias = "soyo"
            keyPassword = "soyo2026key"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("soyo")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("soyo")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
